import { useDataQuery } from "@dhis2/app-runtime";

// Central app constants
export const PROGRAM_ID = "UxK2o06ScIe"; // School Inspection

const eventsQuery = {
  events: {
    resource: "tracker/events",
    params: ({ orgUnitId }) => ({
      program: PROGRAM_ID,
      orgUnit: orgUnitId, // <-- kommer nå fra variabel
      fields: "event,occurredAt,orgUnitName,dataValues[dataElement,value]",
      order: "occurredAt:desc",
      pageSize: 20,
    }),
  },
};
export const useInspectionEvents = (id) => {
  const { data, loading, error, refetch } = useDataQuery(eventsQuery, {
    variables: { orgUnitId: id },
  });

  // Håndter ulike mulige strukturer fra API
  const events =
    data?.events?.instances ?? data?.events?.events ?? data?.events ?? [];

  // Hvis events er et objekt, ikke array, konverter det til []
  const safeEvents = Array.isArray(events) ? events : [];

  return { events: safeEvents, loading, error, refetch };
};
