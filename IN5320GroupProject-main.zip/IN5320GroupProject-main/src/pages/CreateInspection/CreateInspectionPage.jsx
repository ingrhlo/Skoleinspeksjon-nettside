// src/pages/CreateInspection/CreateInspectionPage.jsx
import { useDataMutation } from "@dhis2/app-runtime";
import {
  Button,
  ButtonStrip,
  Card,
  IconCheckmarkCircle24,
  IconError24,
  IconInfo16,
  InputField,
  NoticeBox,
} from "@dhis2/ui";
import { IconChevronLeft16 } from "@dhis2/ui-icons";
import { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useInspectionEvents } from "../../api";
import styles from "./CreateInspectionPage.module.css";

// Configure your DHIS2 program + stage here
const PROGRAM_ID = "UxK2o06ScIe"; // School Inspection
const PROGRAM_STAGE_ID = "eJiBjm9Rl7E"; // Program Stage for inspection

// Required data elements for School Inspection
// valueType mapping:
// - "integer" => integer numbers (step 1)
// - "number"  => decimal allowed (step any)
const DATA_ELEMENTS = [
  {
    id: "HcLtOns1ZQO",
    label: "Number of learners in a school",
    type: "integer",
    min: 0,
    required: true,
  },
  {
    id: "paoyTAg0cI9",
    label: "Number of teachers in a school",
    type: "integer",
    min: 0,
    required: true,
  },
  {
    id: "INpK1I4glqo",
    label: "Books (Total)",
    type: "integer",
    min: 0,
    required: true,
  },
  {
    id: "Se1MYpht225",
    label: "Seats (Total)",
    type: "integer",
    min: 0,
    required: true,
  },
  {
    id: "QXcKg7GSr4e",
    label: "Toilet for boys",
    type: "number",
    min: 0,
    required: true,
  },
  {
    id: "OGmIo4kFUYr",
    label: "Toilet for girls",
    type: "number",
    min: 0,
    required: true,
  },
  {
    id: "I13NTyLrHBm",
    label: "Toilet for teachers",
    type: "integer",
    min: 0,
    required: true,
  },
  {
    id: "ya5SyA5hej4",
    label: "Number of classrooms",
    type: "number",
    min: 0,
    required: true,
  },
];

// Mutation to create a tracker event
const createEventMutation = {
  type: "create",
  resource: "tracker",
  params: { async: "false" },
  data: ({ orgUnit, occurredAt, dataValues }) => ({
    events: [
      {
        program: PROGRAM_ID,
        programStage: PROGRAM_STAGE_ID,
        orgUnit,
        occurredAt,
        status: "ACTIVE",
        dataValues,
      },
    ],
  }),
};

const CreateInspectionPage = () => {
  const navigate = useNavigate();
  const { id } = useParams(); // orgUnit ID from URL

  const [mutate, { loading, error }] = useDataMutation(createEventMutation);

  // Form state
  const [date, setDate] = useState(() => {
    const d = new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  });

  const [values, setValues] = useState(() => {
    const init = {};
    DATA_ELEMENTS.forEach((de) => {
      init[de.id] = de.type === "boolean" ? false : "";
    });
    return init;
  });
  const [previousValues, setPreviousValues] = useState({});
  // Fetch previous inspection report
  const {
    events: previousEvents,
    loading: prevLoading,
    error: prevError,
  } = useInspectionEvents(id);

  // Prefill form with previous report values (only on first load)
  useMemo(() => {
    if (previousEvents && previousEvents.length > 0) {
      const lastEvent = previousEvents[0];
      if (lastEvent && lastEvent.dataValues) {
        const prevVals = {};
        setValues((prev) => {
          const newVals = { ...prev };
          DATA_ELEMENTS.forEach((de) => {
            const found = lastEvent.dataValues.find(
              (dv) => dv.dataElement === de.id
            );
            if (found && found.value !== undefined && found.value !== null) {
              newVals[de.id] = found.value;
              prevVals[de.id] = found.value;
            }
          });
          return newVals;
        });
        setPreviousValues(prevVals);
      }
    }
    // Only run on first load
    // eslint-disable-next-line
  }, [previousEvents]);
  const [fieldErrors, setFieldErrors] = useState({});
  const [formError, setFormError] = useState("");

  const occurredAt = date || new Date().toISOString().split("T")[0];

  const handleChange = (id, type) => (e) => {
    const val = type === "boolean" ? e.target.checked : e.target.value;
    setValues((prev) => ({ ...prev, [id]: val }));
  };

  const getFieldClassName = (id) => {
    if (
      !previousValues[id] ||
      values[id] === "" ||
      values[id] === previousValues[id]
    ) {
      return "";
    }
    const current = Number(values[id]);
    const previous = Number(previousValues[id]);
    if (!isNaN(current) && !isNaN(previous)) {
      if (current > previous) return styles.fieldIncreased;
      if (current < previous) return styles.fieldDecreased;
    }
    return "";
  };

  const buildDataValues = () => {
    const dv = [];
    const errors = {};
    let hasError = false;
    for (const de of DATA_ELEMENTS) {
      const raw = values[de.id];
      if (de.type === "integer" || de.type === "number") {
        if (raw === "" || raw === null || raw === undefined) {
          if (de.required) {
            errors[de.id] = "Required field";
            hasError = true;
            continue;
          }
        } else {
          const num = Number(raw);
          if (!Number.isFinite(num)) {
            errors[de.id] = "Invalid number";
            hasError = true;
            continue;
          }
          if (typeof de.min === "number" && num < de.min) {
            errors[de.id] = `Must be ≥ ${de.min}`;
            hasError = true;
            continue;
          }
          if (de.type === "integer" && !Number.isInteger(num)) {
            errors[de.id] = "Must be an integer";
            hasError = true;
            continue;
          }
          dv.push({ dataElement: de.id, value: num });
        }
      } else if (de.type === "boolean") {
        if (de.required && typeof raw !== "boolean") {
          errors[de.id] = "Required field";
          hasError = true;
          continue;
        }
        dv.push({ dataElement: de.id, value: Boolean(raw) });
      } else {
        // text
        if (raw && String(raw).trim() !== "") {
          dv.push({ dataElement: de.id, value: String(raw).trim() });
        } else if (de.required) {
          errors[de.id] = "Required field";
          hasError = true;
          continue;
        }
      }
    }
    setFieldErrors(errors);
    return hasError ? null : dv;
  };

  const handleSubmit = async (e) => {
    e?.preventDefault?.();
    setFormError("");
    const dataValues = buildDataValues();
    if (!dataValues) {
      setFormError("Please correct the highlighted fields.");
      return;
    }
    try {
      await mutate({ orgUnit: id, occurredAt, dataValues });
      navigate(`/schools/${id}`);
    } catch (err) {
      setFormError("Failed to create inspection. " + (err?.message || ""));
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.headerBack}>
        <Button
          secondary
          small
          icon={<IconChevronLeft16 />}
          onClick={() => navigate(-1)}
        >
          Back
        </Button>
      </div>
      <Card className={styles.card}>
        <div className={styles.pageHeader}>
          <h1 className={styles.pageTitle}>School Inspection form</h1>
        </div>
        <form className={styles.form} onSubmit={handleSubmit}>
          {prevLoading && <NoticeBox title="Loading previous report..." />}
          {prevError && (
            <NoticeBox
              error
              title="Could not load previous report"
              icon={<IconError24 />}
            >
              {prevError.message}
            </NoticeBox>
          )}
          {previousEvents && previousEvents.length > 0 && (
            <NoticeBox
              title="Previous report values loaded"
              icon={<IconInfo16 />}
            >
              Prefilled with last inspection numbers. Please update as needed.
            </NoticeBox>
          )}
          <div className={styles.formSection}>
            <h2 className={styles.formSectionTitle}>Inspection Information</h2>
            <div className={styles.fieldRow}>
              <InputField
                label="Date of visit"
                type="date"
                value={date}
                onChange={({ value }) => setDate(value)}
                max={new Date().toISOString().split("T")[0]}
                required
              />
            </div>
          </div>

          <div className={styles.formSection}>
            <h2 className={styles.formSectionTitle}>Resource count</h2>
            <div className={styles.resourceGrid}>
              <div className={getFieldClassName("INpK1I4glqo")}>
                <InputField
                  label="Books (Total)"
                  type="number"
                  value={values["INpK1I4glqo"]}
                  onChange={({ value }) =>
                    setValues((prev) => ({ ...prev, ["INpK1I4glqo"]: value }))
                  }
                  required
                  min={0}
                  step={1}
                  validationText={fieldErrors["INpK1I4glqo"] || undefined}
                  error={!!fieldErrors["INpK1I4glqo"]}
                  placeholder="Amount of books that can be used"
                />
              </div>
              <div className={getFieldClassName("Se1MYpht225")}>
                <InputField
                  label="Seats (Total)"
                  type="number"
                  value={values["Se1MYpht225"]}
                  onChange={({ value }) =>
                    setValues((prev) => ({ ...prev, ["Se1MYpht225"]: value }))
                  }
                  required
                  min={0}
                  step={1}
                  validationText={fieldErrors["Se1MYpht225"] || undefined}
                  error={!!fieldErrors["Se1MYpht225"]}
                  placeholder="Amount of seats that can be used"
                />
              </div>
              <div className={getFieldClassName("HcLtOns1ZQO")}>
                <InputField
                  label="Number of learners in a school"
                  type="number"
                  value={values["HcLtOns1ZQO"]}
                  onChange={({ value }) =>
                    setValues((prev) => ({ ...prev, ["HcLtOns1ZQO"]: value }))
                  }
                  required
                  min={0}
                  step={1}
                  validationText={fieldErrors["HcLtOns1ZQO"] || undefined}
                  error={!!fieldErrors["HcLtOns1ZQO"]}
                  placeholder="Number of learners in school"
                />
              </div>
              <div className={getFieldClassName("paoyTAg0cI9")}>
                <InputField
                  label="Number of teachers in a school"
                  type="number"
                  value={values["paoyTAg0cI9"]}
                  onChange={({ value }) =>
                    setValues((prev) => ({ ...prev, ["paoyTAg0cI9"]: value }))
                  }
                  required
                  min={0}
                  step={1}
                  validationText={fieldErrors["paoyTAg0cI9"] || undefined}
                  error={!!fieldErrors["paoyTAg0cI9"]}
                  placeholder="Number of teachers in school"
                />
              </div>
            </div>

            <div className={styles.resourceGrid}>
              <div className={getFieldClassName("QXcKg7GSr4e")}>
                <InputField
                  label="Toilet for boys"
                  type="number"
                  value={values["QXcKg7GSr4e"]}
                  onChange={({ value }) =>
                    setValues((prev) => ({ ...prev, ["QXcKg7GSr4e"]: value }))
                  }
                  required
                  min={0}
                  step="any"
                  validationText={fieldErrors["QXcKg7GSr4e"] || undefined}
                  error={!!fieldErrors["QXcKg7GSr4e"]}
                  placeholder="Number of toilets for boys"
                />
              </div>
              <div className={getFieldClassName("OGmIo4kFUYr")}>
                <InputField
                  label="Toilet for girls"
                  type="number"
                  value={values["OGmIo4kFUYr"]}
                  onChange={({ value }) =>
                    setValues((prev) => ({ ...prev, ["OGmIo4kFUYr"]: value }))
                  }
                  required
                  min={0}
                  step="any"
                  validationText={fieldErrors["OGmIo4kFUYr"] || undefined}
                  error={!!fieldErrors["OGmIo4kFUYr"]}
                  placeholder="Number of toilets for girls"
                />
              </div>
              <div className={getFieldClassName("I13NTyLrHBm")}>
                <InputField
                  label="Toilet for teachers"
                  type="number"
                  value={values["I13NTyLrHBm"]}
                  onChange={({ value }) =>
                    setValues((prev) => ({ ...prev, ["I13NTyLrHBm"]: value }))
                  }
                  required
                  min={0}
                  step={1}
                  validationText={fieldErrors["I13NTyLrHBm"] || undefined}
                  error={!!fieldErrors["I13NTyLrHBm"]}
                  placeholder="Number of toilets for teachers"
                />
              </div>
              <div className={getFieldClassName("ya5SyA5hej4")}>
                <InputField
                  label="Number of classrooms"
                  type="number"
                  value={values["ya5SyA5hej4"]}
                  onChange={({ value }) =>
                    setValues((prev) => ({ ...prev, ["ya5SyA5hej4"]: value }))
                  }
                  required
                  min={0}
                  step="any"
                  validationText={fieldErrors["ya5SyA5hej4"] || undefined}
                  error={!!fieldErrors["ya5SyA5hej4"]}
                  placeholder="Number of classrooms"
                />
              </div>
            </div>
          </div>
          {(formError || error) && (
            <NoticeBox error title="Form Error" icon={<IconError24 />}>
              {formError || error?.message}
            </NoticeBox>
          )}
          <ButtonStrip end className={styles.buttonStrip}>
            <Button secondary onClick={() => navigate(-1)} disabled={loading}>
              Cancel
            </Button>
            <Button
              primary
              type="submit"
              disabled={loading}
              icon={<IconCheckmarkCircle24 />}
            >
              {loading ? "Saving…" : "Save report"}
            </Button>
          </ButtonStrip>
        </form>
      </Card>
    </div>
  );
};

export default CreateInspectionPage;
