import { useDataEngine, useDataQuery } from "@dhis2/app-runtime";
import {
  Button,
  Card,
  CircularLoader,
  DataTable,
  DataTableBody,
  DataTableCell,
  DataTableColumnHeader,
  DataTableHead,
  DataTableRow,
  IconAdd16,
  IconChevronLeft16,
  IconFileDocument16,
  NoticeBox,
  Tab,
  TabBar,
  Tag,
} from "@dhis2/ui";
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useInspectionEvents } from "../../api";
import styles from "./SchoolDetailPage.module.css";

const PHOTO_DATASTORE_NAMESPACE = "in5320-school-photos";

const PROGRAM_ID = 'UxK2o06ScIe';

function getRatioColor(key, value) {
    if (value === null || value === undefined) return "gray";

    const thresholds = {
        seat_to_learner: 1,
        textbook_to_learner: 1,
        learner_to_classroom: 53,
        learner_to_teacher: 45,
        learner_to_toilet: 25,
    };

    if (key == "seat_to_learner" || key == "textbook_to_learner")
      return value < thresholds[key] ? "red" : "green";  
    else
      return value < thresholds[key] ? "green" : "red";
}

function getChangeColor(row) {
    if (row.percentChange === null || row.difference === null) return "gray";

    const diff = Number(row.difference);
    const percent = Number(row.percentChange);

    if (percent <= -25 || diff <= -5) return "red";
    if (percent < 0) return "orange";
    if (percent === 0) return "gray";
    return "green";
}

function getRequirementStatus(key, value) {
    const color = getRatioColor(key, value);
    if (color === "green") return <Tag positive>Requirement met</Tag>;
    if (color === "red") return <Tag negative>Requirement not met</Tag>;
    return <Tag neutral>No data</Tag>;
}

const query = {
  orgUnit: {
    resource: "organisationUnits",
    id: ({ orgUnitId }) => orgUnitId,
    params: {
      fields: [
        "id",
        "name",
        "displayName",
        "shortName",
        "description",
        "openingDate",
        "parent[id,displayName]",
        "geometry",
      ],
    },
  },
};

const DATAELEMENTS_QUERY = {
  dataElements: {
    resource: "dataElements",
    params: ({ ids }) => ({
      filter: `id:in:[${ids.join(",")}]`,
      fields: "id,displayName",
    }),
  },
};

const SchoolDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const engine = useDataEngine();

  const {
    events,
    loading: eventsLoading,
    error: eventsError,
    refetch: refetchEvents,
  } = useInspectionEvents(id);

  const latestEvent = events?.[0] || null;
  const secondLatestEvent = events?.[1] || null;

const STANDARD_IDS = {
    seats: "Se1MYpht225",
    learners: "HcLtOns1ZQO",
    books: "INpK1I4glqo",
    classrooms: "ya5SyA5hej4",
    teachers: "paoyTAg0cI9",
    toilets_boys: "QXcKg7GSr4e",
    toilets_girls: "OGmIo4kFUYr",
    toilets_teachers: "I13NTyLrHBm",
};

  const dataElementIds = useMemo(() => {
    const ids = new Set();
    [latestEvent, secondLatestEvent].forEach((ev) => {
      ev?.dataValues?.forEach((dv) => ids.add(dv.dataElement));
    });
    return Array.from(ids);
  }, [latestEvent, secondLatestEvent]);

  const {
    loading: loadingDE,
    error: errorDE,
    data: dataDE,
    refetch: fetchDataElements,
  } = useDataQuery(DATAELEMENTS_QUERY, { lazy: true });

  useEffect(() => {
    if (dataElementIds.length > 0) {
      fetchDataElements({ ids: dataElementIds });
    }
  }, [dataElementIds, fetchDataElements]);
  const nameMap = useMemo(() => {
    const map = {};
    dataDE?.dataElements?.dataElements?.forEach((el) => {
      map[el.id] = el.displayName;
    });
    return map;
  }, [dataDE]);

  console.log("dataElementIds", dataElementIds);
  console.log("dataDE", dataDE);
  console.log("nameMap", nameMap);

  const {
    loading: orgUnitLoading,
    error: orgUnitError,
    data,
  } = useDataQuery(query, {
    variables: { orgUnitId: id },
  });

  const [photo, setPhoto] = useState(null);
  const [photoError, setPhotoError] = useState(null);
  const [photoLoading, setPhotoLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("inspections");
  const [deletingEventId, setDeletingEventId] = useState(null);
  const [deleteError, setDeleteError] = useState(null);

  const handleBackClick = () => navigate("/");

  const handleDeleteEvent = async (eventId) => {
    const confirmed = window.confirm(
      "Are you sure you want to delete this inspection report? This action cannot be undone."
    );

    if (!confirmed) return;

    setDeletingEventId(eventId);
    setDeleteError(null);

    try {
      // DHIS2 Tracker API requires using the tracker endpoint with importStrategy=DELETE
      await engine.mutate({
        resource: "tracker",
        type: "create",
        params: {
          importStrategy: "DELETE",
        },
        data: {
          events: [
            {
              event: eventId,
            },
          ],
        },
      });
      await refetchEvents();
    } catch (err) {
      console.error("Delete error:", err);
      setDeleteError(err.message || "Failed to delete inspection report");
      alert(
        "Failed to delete inspection report: " +
          (err.message || "Unknown error")
      );
    } finally {
      setDeletingEventId(null);
    }
  };

  const BackButton = () => (
    <Button
      small
      secondary
      icon={<IconChevronLeft16 />}
      onClick={handleBackClick}
    >
      Back to List
    </Button>
  );

  useEffect(() => {
    let cancelled = false;

    const fetchPhoto = async () => {
      setPhotoLoading(true);
      setPhotoError(null);

      try {
        const res = await engine.query({
          photo: {
            resource: `dataStore/${PHOTO_DATASTORE_NAMESPACE}`,
            id,
          },
        });

        if (!cancelled) {
          setPhoto(res.photo);
        }
      } catch (e) {
        if (!cancelled) {
          if (e.details?.httpStatusCode === 404) {
            setPhoto(null);
          } else {
            setPhotoError(e);
          }
        }
      } finally {
        if (!cancelled) setPhotoLoading(false);
      }
    };

    fetchPhoto();
    return () => {
      cancelled = true;
    };
  }, [engine, id]);

  if (orgUnitLoading || eventsLoading || loadingDE) {
    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <BackButton />
        </div>
        <div className={styles.centerContent}>
          <CircularLoader />
        </div>
      </div>
    );
  }

  if (orgUnitError || eventsError || errorDE) {
    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <BackButton />
        </div>
        <NoticeBox error title="Error loading school details">
          {orgUnitError?.message || eventsError?.message || errorDE?.message}
        </NoticeBox>
      </div>
    );
  }

  const school = data?.orgUnit;
  if (!school) {
    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <BackButton />
        </div>
        <NoticeBox warning title="School not found">
          The requested school could not be found.
        </NoticeBox>
      </div>
    );
  }

  const hasGeometry =
    school.geometry &&
    school.geometry.type === "Point" &&
    Array.isArray(school.geometry.coordinates);

  const latitude = hasGeometry ? school.geometry.coordinates[1] : null;
  const longitude = hasGeometry ? school.geometry.coordinates[0] : null;

  const mapDataValues = (ev) => {
    if (!ev?.dataValues) return {};
    return ev.dataValues.reduce((acc, dv) => {
      const num = Number(dv.value);
      acc[dv.dataElement] = Number.isNaN(num) ? dv.value : num;
      return acc;
    }, {});
  };

  // Helper function to round to 2 decimal places
  function round2(value) {
    if (value === null || value === undefined || isNaN(value)) return null;
    return Number(
        (Math.round(Number(value) * 100) / 100).toFixed(2)
    );
}

const computeRatios = (values) => {
    if (!values) return {};

    const learners = values[STANDARD_IDS.learners] || 0;
    const teachers = values[STANDARD_IDS.teachers] || 0;
    const seats = values[STANDARD_IDS.seats] || 0;
    const books = values[STANDARD_IDS.books] || 0;
    const classrooms = values[STANDARD_IDS.classrooms] || 0;
    const toilets = (values[STANDARD_IDS.toilets_girls] || 0) + (values[STANDARD_IDS.toilets_boys] || 0) ;

    return {
        seat_to_learner:
            learners ? round2(seats / learners) : null,

        textbook_to_learner:
            learners ? round2(books / learners) : null,

        learner_to_classroom:
            classrooms ? round2(learners / classrooms) : null,

        learner_to_teacher:
            teachers ? round2(learners / teachers) : null,

        learner_to_toilet:
            toilets ? round2(learners / toilets) : null,
    };
};



    const latestValues = mapDataValues(latestEvent);
    const secondValues = mapDataValues(secondLatestEvent);

    const latestRatios = computeRatios(latestValues);
    const secondRatios = computeRatios(secondValues);

  const compareAll = () => {
    const safeLatest = latestValues || {};
    const safeSecond = secondValues || {};
    
    const allKeys = Array.from(
        new Set([
            ...Object.keys(safeLatest),
            ...Object.keys(safeSecond)
        ])
    );

    return allKeys.map((deId) => {
      const prev = safeSecond[deId] ?? null;
      const curr = safeLatest[deId] ?? null;

      const diff = curr !== null && prev !== null ? curr - prev : null;

      const percent =
        curr !== null && prev !== null && prev !== 0
          ? ((diff / prev) * 100).toFixed(1)
          : null;

      return {
        dataElement: deId,
        previous: prev,
        latest: curr,
        difference: diff,
        percentChange: percent,
      };
    });
  };

  const getStatusTag = (row) => {
    const { difference, percentChange } = row;
    if (difference === null || percentChange === null)
      return <Tag neutral>No data</Tag>;
    const diff = Number(difference);
    const percent = Number(percentChange);
    if (percent <= -25 || diff <= -5) return <Tag negative>Decrease</Tag>;
    if (percent < 0) return <Tag warning>Slight drop</Tag>;
    if (percent === 0) return <Tag>Stable</Tag>;
    return <Tag positive>Increase</Tag>;
  };

  const imageSrc = photo?.dataUrl || null;

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <BackButton />
      </div>

      <Card>
        <div className={styles.cardHeader}>
          <h1 className={styles.schoolTitle}>
            {school.displayName || school.name}
          </h1>
        </div>
        <div className={styles.cardContent}>
          <h2 className={styles.sectionTitle}>School Information</h2>
          <div className={styles.infoFlex}>
            <div className={styles.infoGrid}>
              <div className={`${styles.fullWidth} ${styles.inlineRow}`}>
                <div className={styles.inlineItem}>
                  <div className={styles.infoLabel}>School Name</div>
                  <div className={styles.infoValue}>
                    {school.displayName || school.name}
                  </div>
                </div>
                {school.shortName && (
                  <div className={styles.inlineItem}>
                    <div className={styles.infoLabel}>Short Name</div>
                    <div className={styles.infoValue}>{school.shortName}</div>
                  </div>
                )}
              </div>
              {school.description && (
                <div
                  className={`${styles.infoItem} ${styles.fullWidth} ${styles.wideRow}`}
                >
                  <div className={styles.infoLabel}>Description</div>
                  <div className={styles.infoValue}>{school.description}</div>
                </div>
              )}
              {school.openingDate && (
                <div className={styles.infoItem}>
                  <div className={styles.infoLabel}>Opening Date</div>
                  <div className={styles.infoValue}>
                    {new Date(school.openingDate).toLocaleDateString()}
                  </div>
                </div>
              )}
              {school.parent && (
                <div className={styles.infoItem}>
                  <div className={styles.infoLabel}>Parent Organisation</div>
                  <div className={styles.infoValue}>
                    {school.parent.displayName}
                  </div>
                </div>
              )}
              {hasGeometry && (
                <div className={styles.infoItem}>
                  <div className={styles.infoLabel}>Coordinates</div>
                  <div className={styles.infoValue}>
                    {latitude}, {longitude}
                  </div>
                </div>
              )}
            </div>
            <div className={styles.photoWrapper}>
              {photoLoading ? (
                <div className={styles.photoSkeleton}>Loading…</div>
              ) : imageSrc ? (
                <img
                  src={imageSrc}
                  alt={school.displayName || "School photo"}
                  className={styles.schoolPhoto}
                />
              ) : (
                <div className={styles.photoEmpty}>No photo uploaded</div>
              )}
              {photoError && (
                <div className={styles.photoError}>{photoError.message}</div>
              )}
            </div>
          </div>
          <div className={styles.actionsRow}>
            <Button
              primary
              icon={<IconAdd16 />}
              onClick={() => navigate(`/schools/${id}/CreateInspection`)}
            >
              Generate new report
            </Button>
          </div>
        </div>
      </Card>

      <div className={styles.cardSpacing}>
        <Card>
          <TabBar>
            <Tab
              selected={activeTab === "inspections"}
              onClick={() => setActiveTab("inspections")}
            >
              Inspections
            </Tab>
            <Tab
              selected={activeTab === "resources"}
              onClick={() => setActiveTab("resources")}
            >
              Resource count
            </Tab>
          </TabBar>

          <div className={styles.tabContent}>
            {activeTab === "inspections" && (
              <div className={styles.cardContent}>
                <div className={styles.reportHeader}>
                  <h2
                    className={`${styles.sectionTitle} ${styles.reportTitle}`}
                  >
                    Inspection Reports
                  </h2>
                  <span className={styles.reportCount}>
                    {events?.length || 0}{" "}
                    {events?.length === 1 ? "report" : "reports"}
                  </span>
                </div>

                {events && events.length > 0 ? (
                  <DataTable>
                    <DataTableHead>
                      <DataTableRow>
                        <DataTableColumnHeader className={styles.iconCell} />
                        <DataTableColumnHeader className={styles.dateCell}>
                          Inspection Date
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>Actions</DataTableColumnHeader>
                      </DataTableRow>
                    </DataTableHead>
                    <DataTableBody>
                      {events.map((ev) => (
                        <DataTableRow key={ev.event}>
                          <DataTableCell>
                            <IconFileDocument16 />
                          </DataTableCell>
                          <DataTableCell>
                            <span className={styles.dateText}>
                              {new Date(ev.occurredAt).toLocaleDateString(
                                "en-US",
                                {
                                  year: "numeric",
                                  month: "long",
                                  day: "numeric",
                                }
                              )}
                            </span>
                          </DataTableCell>
                          <DataTableCell>
                            <div className={styles.actionButtons}>
                              <Button
                                small
                                onClick={() =>
                                  navigate(`/schools/${id}/events/${ev.event}`)
                                }
                              >
                                View Details
                              </Button>
                              <Button
                                small
                                destructive
                                onClick={() => handleDeleteEvent(ev.event)}
                                disabled={deletingEventId === ev.event}
                              >
                                {deletingEventId === ev.event
                                  ? "Deleting..."
                                  : "Delete"}
                              </Button>
                            </div>
                          </DataTableCell>
                        </DataTableRow>
                      ))}
                    </DataTableBody>
                  </DataTable>
                ) : (
                  <NoticeBox title="No inspections found">
                    There are no inspection reports for this school yet.
                  </NoticeBox>
                )}
              </div>
            )}

            {activeTab === "resources" &&
              (latestEvent ? (
                <div className={styles.cardContent}>
                  <h2>Minimum Standards for Ratios</h2>
                    <DataTable>
                    <DataTableHead>
                      <DataTableRow>
                        <DataTableColumnHeader>Requirement</DataTableColumnHeader>
                        <DataTableColumnHeader>Status</DataTableColumnHeader>
                      </DataTableRow>
                    </DataTableHead>
                    <DataTableBody>
                      <DataTableRow key="seat_to_learner">
                            <DataTableCell>Seat-to-learner</DataTableCell>
                                        <DataTableCell>
                                          {getRequirementStatus("seat_to_learner", latestRatios.seat_to_learner)}
                                        </DataTableCell>
                      </DataTableRow>

                      <DataTableRow key="textbook_to_learner">
                        <DataTableCell>Textbook-to-learner</DataTableCell>
                        <DataTableCell>
                          {getRequirementStatus("textbook_to_learner", latestRatios.textbook_to_learner)}
                        </DataTableCell>
                      </DataTableRow>

                      <DataTableRow key="learner_to_classroom">
                        <DataTableCell>Learner-to-classroom</DataTableCell>
                        <DataTableCell>
                          {getRequirementStatus("learner_to_classroom", latestRatios.learner_to_classroom)}
                        </DataTableCell>
                      </DataTableRow>

                      <DataTableRow key="learner_to_teacher">
                        <DataTableCell>Learner-to-teacher</DataTableCell>
                        <DataTableCell>
                          {getRequirementStatus("learner_to_teacher", latestRatios.learner_to_teacher)}
                        </DataTableCell>
                      </DataTableRow>

                      <DataTableRow key="learner_to_toilet">
                        <DataTableCell>Learner-to-toilet</DataTableCell>
                        <DataTableCell>
                          {getRequirementStatus("learner_to_toilet", latestRatios.learner_to_toilet)}
                        </DataTableCell>
                      </DataTableRow>
                    </DataTableBody>
                  </DataTable>



                  {/* Resource count */}
                  <h2>Resource count</h2>

                  <DataTable>
                    <DataTableHead>
                      <DataTableRow>
                        <DataTableColumnHeader>Resource</DataTableColumnHeader>
                        
                        <DataTableColumnHeader>Last</DataTableColumnHeader>
                        <DataTableColumnHeader>Previous</DataTableColumnHeader>
                        <DataTableColumnHeader>
                          Difference
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>% change</DataTableColumnHeader>
                        <DataTableColumnHeader>Status</DataTableColumnHeader>
                      </DataTableRow>
                    </DataTableHead>

                    <DataTableBody>
                      {compareAll().map((row) => (
                        <DataTableRow key={row.dataElement}>
                          <DataTableCell>
                            {nameMap[row.dataElement] || row.dataElement}
                          </DataTableCell>

                            <DataTableCell>{row.latest ?? "-"}</DataTableCell>
                            <DataTableCell>{row.previous ?? "-"}</DataTableCell>
                          <DataTableCell>
                            {row.difference !== null ? row.difference : "-"}
                          </DataTableCell>
                          <DataTableCell>
                            {row.percentChange !== null
                              ? `${row.percentChange}%`
                              : "-"}
                          </DataTableCell>
                          <DataTableCell>{getStatusTag(row)}</DataTableCell>
                        </DataTableRow>
                      ))}
                    </DataTableBody>
                  </DataTable>
                </div>
              ) : (
                <div className={styles.cardContent}>
                  <NoticeBox title="Not enough data">
                    Need at least one inspection event to show resource
                    information.
                  </NoticeBox>
                </div>
              ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default SchoolDetailPage;
