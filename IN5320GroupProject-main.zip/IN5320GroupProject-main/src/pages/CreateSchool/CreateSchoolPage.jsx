// src/pages/CreateSchoolPage.jsx
import { useDataEngine } from "@dhis2/app-runtime";
import { Button, Card, InputField, TextAreaField } from "@dhis2/ui";
import {
  IconChevronLeft16,
  IconImage16,
  IconLocation16,
} from "@dhis2/ui-icons";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { PROGRAM_ID } from "../../api";
import styles from "./CreateSchoolPage.module.css";

const CLUSTER_ORG_UNIT_ID = "Jj1IUjjPaWf"; // Jambalaya Cluster
const PHOTO_DATASTORE_NAMESPACE = "in5320-school-photos";

const CreateSchoolPage = () => {
  const navigate = useNavigate();
  const engine = useDataEngine();

  const [formData, setFormData] = useState({
    name: "",
    shortName: "",
    openingDate: "",
    description: "",
    latitude: "",
    longitude: "",
  });

  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files && e.target.files[0];
    setImageFile(file || null);

    // Create preview
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    } else {
      setImagePreview(null);
    }
  };

  const extractUid = (res) =>
    res?.response?.uid ||
    res?.uid ||
    res?.response?.object?.uid ||
    res?.response?.importSummaries?.[0]?.reference ||
    null;

  const fileToDataUrl = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    });

  const handleUseMyLocation = () => {
    if (!navigator.geolocation) {
      setErrorMsg("Geolocation is not supported by your browser.");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setFormData((prev) => ({
          ...prev,
          latitude: latitude.toString(),
          longitude: longitude.toString(),
        }));
      },
      (error) => {
        switch (error.code) {
          case error.PERMISSION_DENIED:
            setErrorMsg("Location permission denied.");
            break;
          case error.POSITION_UNAVAILABLE:
            setErrorMsg("Location position unavailable.");
            break;
          case error.TIMEOUT:
            setErrorMsg("Location request timed out.");
            break;
          default:
            setErrorMsg("Could not fetch location.");
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setErrorMsg("");

    try {
      if (
        !formData.name.trim() ||
        !formData.shortName.trim() ||
        !formData.openingDate
      ) {
        throw new Error("Please fill out Name, Short Name and Opening Date.");
      }

      if (new Date(formData.openingDate) > new Date()) {
        throw new Error("Opening date cannot be in the future.");
      }

      let geometry;
      const hasLat = formData.latitude !== "";
      const hasLng = formData.longitude !== "";

      if (hasLat || hasLng) {
        if (!hasLat || !hasLng) {
          throw new Error(
            "Please fill in both latitude and longitude, or leave both empty."
          );
        }

        const lat = parseFloat(formData.latitude);
        const lng = parseFloat(formData.longitude);

        if (Number.isNaN(lat) || Number.isNaN(lng)) {
          throw new Error("Latitude and longitude must be valid numbers.");
        }

        if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
          throw new Error(
            "Latitude must be between -90 and 90, and longitude between -180 and 180."
          );
        }

        geometry = {
          type: "Point",
          coordinates: [lng, lat],
        };
      }

      const payload = {
        name: formData.name.trim(),
        shortName: formData.shortName.trim(),
        openingDate: formData.openingDate,
        parent: { id: CLUSTER_ORG_UNIT_ID },
        ...(formData.description.trim() && {
          description: formData.description.trim(),
        }),
        ...(geometry && { geometry }),
      };

      const res = await engine.mutate({
        type: "create",
        resource: "organisationUnits",
        data: payload,
      });

      const newId = extractUid(res);
      if (!newId) {
        navigate("/");
        return;
      }

      // Automatically assign the newly created school (org unit) to the program
      try {
        await engine.mutate({
          type: "create",
          resource: `programs/${PROGRAM_ID}/organisationUnits/${newId}`,
          data: {},
        });
      } catch (assignErr) {
        console.error(
          "Failed to assign school to program (non-blocking):",
          assignErr
        );
      }

      if (imageFile) {
        try {
          const dataUrl = await fileToDataUrl(imageFile);

          const photoPayload = {
            name: imageFile.name,
            mimeType: imageFile.type,
            size: imageFile.size,
            dataUrl,
          };

          await engine.mutate({
            type: "create",
            resource: `dataStore/${PHOTO_DATASTORE_NAMESPACE}/${newId}`,
            data: photoPayload,
          });
        } catch (uploadErr) {
          console.error(
            "Error converting/saving image to dataStore:",
            uploadErr
          );
        }
      }

      navigate(`/schools/${newId}`);
    } catch (err) {
      setErrorMsg(err?.message || String(err));
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = () => {
    navigate("/");
  };

  return (
    <div className={styles.container}>
      <div className={styles.headerBack}>
        <Button
          secondary
          small
          icon={<IconChevronLeft16 />}
          onClick={() => navigate(-1)}
        >
          Back
        </Button>
      </div>
      <Card className={styles.card}>
        <div className={styles.pageHeader}>
          <h1 className={styles.pageTitle}>Register a new school</h1>
        </div>

        {errorMsg && <div className={styles.errorBox}>{errorMsg}</div>}

        <form onSubmit={handleSubmit} className={styles.form}>
          {/* School Name and Short Name */}
          <div className={styles.formRow}>
            <div className={styles.formGroup}>
              <InputField
                label={"School Name"}
                value={formData.name}
                onChange={({ value }) =>
                  setFormData((prev) => ({ ...prev, name: value }))
                }
                required
                placeholder={"Enter school name"}
                disabled={submitting}
              />
            </div>

            <div className={styles.formGroup}>
              <InputField
                label={"Short Name"}
                value={formData.shortName}
                onChange={({ value }) =>
                  setFormData((prev) => ({ ...prev, shortName: value }))
                }
                required
                placeholder={"Enter short name"}
                disabled={submitting}
              />
            </div>
          </div>

          {/* Opening Date and Geolocation */}
          <div className={styles.formRow}>
            <div className={styles.formGroup}>
              <InputField
                label={"Opening Date"}
                type={"date"}
                value={formData.openingDate}
                onChange={({ value }) =>
                  setFormData((prev) => ({ ...prev, openingDate: value }))
                }
                required
                disabled={submitting}
                max={new Date().toISOString().split("T")[0]}
              />
            </div>
            <div className={styles.formGroup}>
              <div className={styles.flexRow}>
                <InputField
                  label={"Latitude (optional)"}
                  type="number"
                  step="any"
                  value={formData.latitude}
                  onChange={({ value }) =>
                    setFormData((prev) => ({ ...prev, latitude: value }))
                  }
                  placeholder={"e.g. 13.4529"}
                  disabled={submitting}
                />

                <InputField
                  label={"Longitude (optional)"}
                  type="number"
                  step="any"
                  value={formData.longitude}
                  onChange={({ value }) =>
                    setFormData((prev) => ({ ...prev, longitude: value }))
                  }
                  placeholder={"e.g. -16.6783"}
                  disabled={submitting}
                />

                <Button
                  type="button"
                  onClick={handleUseMyLocation}
                  disabled={submitting}
                  icon={<IconLocation16 />}
                  secondary
                >
                  Use My Location
                </Button>
              </div>
            </div>
          </div>

          {/* Description and Photo */}
          <div className={styles.formRow}>
            <div className={styles.formGroup}>
              <TextAreaField
                label={"Description (optional)"}
                value={formData.description}
                onChange={({ value }) =>
                  setFormData((prev) => ({ ...prev, description: value }))
                }
                placeholder={
                  "Short description of the school (e.g. location, type, context)"
                }
                rows={6}
                disabled={submitting}
              />
            </div>

            <div className={styles.formGroup}>
              <label>
                School photo <span>(optional)</span>
              </label>
              <input
                id="image"
                name="image"
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                disabled={submitting}
                style={{ display: "none" }}
              />
              {!imagePreview && (
                <Button
                  type="button"
                  onClick={() => document.getElementById("image").click()}
                  disabled={submitting}
                  icon={<IconImage16 />}
                  secondary
                >
                  Choose photo
                </Button>
              )}
              {imagePreview && (
                <div className={styles.imagePreview}>
                  <img src={imagePreview} alt="School preview" />
                  <div className={styles.photoButtons}>
                    <Button
                      type="button"
                      onClick={() => document.getElementById("image").click()}
                      disabled={submitting}
                      icon={<IconImage16 />}
                      small
                    >
                      Change photo
                    </Button>
                    <Button
                      type="button"
                      destructive
                      small
                      onClick={() => {
                        setImageFile(null);
                        setImagePreview(null);
                        document.getElementById("image").value = "";
                      }}
                      disabled={submitting}
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className={styles.formActions}>
            <Button type="submit" disabled={submitting} primary>
              {submitting ? "Creating…" : "Create School"}
            </Button>
            <Button type="button" onClick={handleCancel} disabled={submitting}>
              Cancel
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export default CreateSchoolPage;
