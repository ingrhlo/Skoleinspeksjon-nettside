import { useDataEngine } from '@dhis2/app-runtime'
import { Button, ButtonStrip, NoticeBox } from '@dhis2/ui'
import { useEffect, useMemo, useRef, useState } from 'react'

const SAMPLE_QUERY = JSON.stringify(
    {
        me: {
            resource: 'me',
            params: {
                fields: ['id', 'displayName', 'username']
            }
        }
    },
    null,
    2
)

const SAMPLE_MUTATION = JSON.stringify(
    {
        type: 'create',
        resource: 'dataStore/in5320-playground/example',
        data: { hello: 'world', ts: new Date().toISOString() }
    },
    null,
    2
)

/** Lightweight, safe-ish JSON syntax highlighter */
function syntaxHighlight(jsonString) {
    if (!jsonString) return ''
    let json = typeof jsonString === 'string' ? jsonString : JSON.stringify(jsonString, null, 2)
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')

    return json.replace(
        /(\"(\\u[a-fA-F0-9]{4}|\\[^u]|[^\\"])*\"(\s*:)?|\b(true|false|null)\b|-?\d+(\.\d+)?([eE][+-]?\d+)?)/g,
        (match) => {
            let cls = 'json-number'
            if (/^"/.test(match)) {
                cls = /:\s*$/.test(match) ? 'json-key' : 'json-string'
            } else if (/true|false/.test(match)) {
                cls = 'json-boolean'
            } else if (/null/.test(match)) {
                cls = 'json-null'
            }
            return `<span class="${cls}">${match}</span>`
        }
    )
}

let TAB_COUNTER = 1
function makeTab({ title, input, mode }) {
    return {
        id: `tab-${Date.now()}-${TAB_COUNTER++}`,
        title: title || `Query ${TAB_COUNTER}`,
        input: input ?? (mode === 'mutate' ? SAMPLE_MUTATION : SAMPLE_QUERY),
        output: '',
        error: '',
        mode: mode || 'query',
        busy: false
    }
}

export default function Playground() {
    const engine = useDataEngine()

    // Tabs state
    const [tabs, setTabs] = useState(() => [makeTab({ title: 'Query 1', input: SAMPLE_QUERY, mode: 'query' })])
    const [activeId, setActiveId] = useState(tabs[0].id)
    const [renamingId, setRenamingId] = useState(null)
    const renameInputRef = useRef(null)

    // layout & editor refs
    const prevWindowScrollYRef = useRef(0)
    const textareaRef = useRef(null)
    const leftHighlightRef = useRef(null)
    const leftGutterRef = useRef(null)
    const editorWrapperRef = useRef(null)
    const rightContentRef = useRef(null)
    const rightGutterRef = useRef(null)

    const activeTabIndex = tabs.findIndex(t => t.id === activeId)
    const activeTab = tabs[activeTabIndex] ?? tabs[0]

    useEffect(() => {
        if (!activeTab && tabs.length) setActiveId(tabs[0].id)
    }, [tabs, activeTab])

    // create / close / update helpers
    const addTab = (opts = {}) => {
        const t = makeTab({ title: opts.title || `Query ${tabs.length + 1}`, input: opts.input, mode: opts.mode || 'query' })
        setTabs(s => [...s, t])
        setActiveId(t.id)
    }

    const closeTab = (id) => {
        setTabs(prev => {
            const next = prev.filter(t => t.id !== id)
            if (next.length === 0) {
                const newTab = makeTab({ title: 'Query 1', mode: 'query' })
                setActiveId(newTab.id)
                return [newTab]
            }
            if (id === activeId) {
                const idx = prev.findIndex(t => t.id === id)
                const newActive = prev[Math.max(0, idx - 1)].id
                setActiveId(newActive)
            }
            return next
        })
    }

    const updateActive = (patch) => {
        setTabs(prev => prev.map(t => t.id === activeId ? { ...t, ...patch } : t))
    }

    const onRun = async (tabId = activeId) => {
        setTabs(prev => prev.map(t => t.id === tabId ? ({ ...t, busy: true, error: '', output: '' }) : t))
        prevWindowScrollYRef.current = window.scrollY

        const tab = tabs.find(t => t.id === tabId)
        if (!tab) return
        let parsed
        try {
            parsed = JSON.parse(tab.input)
        } catch (e) {
            setTabs(prev => prev.map(t => t.id === tabId ? ({ ...t, error: `Invalid JSON: ${e.message}`, busy: false }) : t))
            return
        }

        try {
            if (tab.mode === 'query') {
                const res = await engine.query(parsed)
                setTabs(prev => prev.map(t => t.id === tabId ? ({ ...t, output: JSON.stringify(res, null, 2) }) : t))
            } else {
                const res = await engine.mutate(parsed)
                setTabs(prev => prev.map(t => t.id === tabId ? ({ ...t, output: JSON.stringify(res, null, 2) }) : t))
            }
        } catch (e) {
            setTabs(prev => prev.map(t => t.id === tabId ? ({ ...t, error: e.message || String(e) }) : t))
        } finally {
            setTabs(prev => prev.map(t => t.id === tabId ? ({ ...t, busy: false }) : t))
            if (prevWindowScrollYRef.current !== undefined) {
                requestAnimationFrame(() => {
                    window.scrollTo(0, prevWindowScrollYRef.current)
                    prevWindowScrollYRef.current = 0
                })
            }
        }
    }

    const switchTab = (id) => {
        setActiveId(id)
    }

    const startRename = (id) => {
        setRenamingId(id)
        requestAnimationFrame(() => renameInputRef.current && renameInputRef.current.focus())
    }
    const finishRename = (id, value) => {
        setTabs(prev => prev.map(t => t.id === id ? ({ ...t, title: value || t.title }) : t))
        setRenamingId(null)
    }

    // editor key handling
    const handleEditorKeyDown = (e) => {
        const el = textareaRef.current
        if (!el) return
        const start = el.selectionStart
        const end = el.selectionEnd
        const value = activeTab.input

        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault(); if (!activeTab.busy) onRun(activeTab.id); return
        }
        if (e.shiftKey && e.key === 'Enter' && !(e.ctrlKey || e.metaKey)) {
            e.preventDefault(); if (!activeTab.busy) onRun(activeTab.id); return
        }

        if (e.key === 'Tab') {
            e.preventDefault()
            const indent = '  '
            if (start !== end) {
                const before = value.slice(0, start)
                const selected = value.slice(start, end)
                const after = value.slice(end)
                const lines = selected.split('\n')
                if (!e.shiftKey) {
                    const replaced = lines.map(l => indent + l).join('\n')
                    const newVal = before + replaced + after
                    updateActive({ input: newVal })
                    requestAnimationFrame(() => {
                        el.selectionStart = start
                        el.selectionEnd = end + indent.length * lines.length
                    })
                } else {
                    const replaced = lines.map(l => {
                        if (l.startsWith(indent)) return l.slice(indent.length)
                        if (l.startsWith('\t')) return l.slice(1)
                        return l
                    }).join('\n')
                    const newVal = before + replaced + after
                    updateActive({ input: newVal })
                    requestAnimationFrame(() => {
                        el.selectionStart = start
                        el.selectionEnd = start + replaced.length
                    })
                }
            } else {
                if (!e.shiftKey) {
                    const newVal = value.slice(0, start) + indent + value.slice(end)
                    updateActive({ input: newVal })
                    requestAnimationFrame(() => {
                        el.selectionStart = el.selectionEnd = start + indent.length
                    })
                } else {
                    const lineStart = value.lastIndexOf('\n', start - 1) + 1
                    if (value.slice(lineStart, lineStart + indent.length) === indent) {
                        const newVal = value.slice(0, lineStart) + value.slice(lineStart + indent.length)
                        updateActive({ input: newVal })
                        const newPos = start - indent.length
                        requestAnimationFrame(() => {
                            el.selectionStart = el.selectionEnd = newPos
                        })
                    }
                }
            }
            return
        }

        if (e.key === 'Enter' && !e.ctrlKey && !e.metaKey) {
            e.preventDefault()
            const lineStart = value.lastIndexOf('\n', start - 1) + 1
            const line = value.slice(lineStart, start)
            const leadingMatch = line.match(/^\s*/u)
            const baseIndent = leadingMatch ? leadingMatch[0] : ''
            const beforeCaretTrimmed = value.slice(0, start).replace(/\s+$/u, '')
            const lastChar = beforeCaretTrimmed.slice(-1)
            let extra = ''
            if (lastChar === '{' || lastChar === '[') extra = '  '
            const insert = '\n' + baseIndent + extra
            const newVal = value.slice(0, start) + insert + value.slice(end)
            updateActive({ input: newVal })
            requestAnimationFrame(() => {
                const pos = start + insert.length
                el.selectionStart = el.selectionEnd = pos
            })
            return
        }
    }

    // ensure highlight + gutter follow textarea scroll
    const handleTextareaScroll = () => {
        const el = textareaRef.current
        if (!el) return
        if (leftHighlightRef.current) leftHighlightRef.current.scrollTop = el.scrollTop
        if (leftGutterRef.current) leftGutterRef.current.scrollTop = el.scrollTop
    }

    const leftLines = activeTab?.input ? activeTab.input.split('\n').length : 1
    const rightLines = activeTab?.output ? activeTab.output.split('\n').length : 1

    useEffect(() => {
        const content = rightContentRef.current
        const gutter = rightGutterRef.current
        if (!content || !gutter) return
        const onScroll = () => {
            gutter.scrollTop = content.scrollTop
            gutter.scrollLeft = content.scrollLeft
        }
        content.addEventListener('scroll', onScroll)
        return () => content.removeEventListener('scroll', onScroll)
    }, [activeTab?.output])

    // Colors: consistent editor colors
    const COMMON = {
        keyColor: '#94b3f6ff',
        stringColor: '#fbbf24',
        bg: '#23340eff',
        panelBg: '#1a5d63ff',
        accent: '#2563eb'
    }
    const colors = COMMON

    const header = useMemo(() => (
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
            <ButtonStrip>
                <Button small onClick={() => updateActive({ mode: 'query' })} primary={activeTab?.mode === 'query'}>
                    Query
                </Button>
                <Button small onClick={() => updateActive({ mode: 'mutate' })} primary={activeTab?.mode === 'mutate'}>
                    Mutate
                </Button>
            </ButtonStrip>

            <div style={{ flex: 1 }} />

            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <div
                    aria-hidden
                    style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: 8,
                        padding: '6px 10px',
                        borderRadius: 999,
                        fontSize: 13,
                        fontWeight: 600,
                        color: '#0b1220',
                        background: colors.accent,
                        boxShadow: '0 1px 0 rgba(0,0,0,0.15)'
                    }}
                >
                    {activeTab?.mode === 'query' ? 'QUERY' : 'MUTATE'}
                </div>

                <Button primary onClick={() => onRun(activeTab.id)} disabled={activeTab?.busy}>
                    {activeTab?.busy ? 'Running…' : (activeTab?.mode === 'query' ? 'Run query' : 'Run mutation')}
                </Button>
            </div>
        </div>
    ), [activeTab?.mode, activeTab?.busy, activeTab?.id, colors.accent])

    // styles
    const styles = {
        root: {
            display: 'flex',
            flexDirection: 'column',
            height: '100vh',
            gap: 12,
            padding: 12,
            boxSizing: 'border-box',
            fontFamily: 'Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial'
        },
        tabsRow: {
            display: 'flex',
            gap: 8,
            alignItems: 'center',
            marginBottom: 6,
            flexShrink: 0
        },
        tab: (active) => ({
            display: 'inline-flex',
            alignItems: 'center',
            gap: 8,
            padding: '10px 14px',
            borderRadius: 10,
            cursor: 'pointer',
            background: active ? '#eaf2ff' : 'rgba(255,255,255,0.03)',
            color: active ? '#071827' : '#cfe8f3',
            border: active ? `1px solid ${colors.accent}` : '1px solid rgba(255,255,255,0.03)',
            fontWeight: 700,
            fontSize: 13,
            boxShadow: active ? '0 6px 18px rgba(37,99,235,0.08)' : 'none'
        }),
        addTabBtn: {
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: 38,
            height: 38,
            borderRadius: 10,
            border: '1px dashed rgba(255,255,255,0.06)',
            background: 'transparent',
            color: '#cfe8f3',
            cursor: 'pointer',
            fontSize: 18,
            lineHeight: 1
        },
        playgroundRow: {
            display: 'flex',
            gap: 12,
            flex: 1,
            minHeight: 0,
            alignItems: 'stretch'
        },
        leftColumn: {
            flex: 1,
            minWidth: 0,
            display: 'flex',
            flexDirection: 'column',
            minHeight: 0,
            background: colors.panelBg,
            borderRadius: 8,
            padding: 12,
            color: '#e6eef6',
            boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.02)'
        },
        editorWrapper: {
            display: 'flex',
            flex: 1,
            width: '100%',
            borderRadius: 6,
            overflow: 'hidden',
            border: '1px solid rgba(255,255,255,0.04)',
            background: colors.bg,
            minHeight: 0
        },
        gutter: {
            width: 44,
            padding: '8px 6px',
            boxSizing: 'border-box',
            textAlign: 'right',
            userSelect: 'none',
            color: '#9fb7c6',
            fontSize: 12,
            lineHeight: 1.45,
            overflow: 'hidden',
            flexShrink: 0
        },
        highlightedWrap: {
            position: 'relative',
            flex: 1,
            minHeight: 0,
            overflow: 'hidden',
            display: 'grid'
        },
        highlightedPre: {
            margin: 0,
            padding: 12,
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word',
            fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
            fontSize: 13,
            lineHeight: 1.45,
            minHeight: '24px',
            boxSizing: 'border-box',
            pointerEvents: 'none',
            gridArea: '1 / 1 / 2 / 2',
            overflow: 'hidden'
        },
        textarea: {
            gridArea: '1 / 1 / 2 / 2',
            width: '100%',
            height: '100%',
            resize: 'none',
            border: 'none',
            padding: 12,
            margin: 0,
            background: 'transparent',
            color: 'transparent',
            caretColor: '#ff1493', // bright pink caret
            fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
            fontSize: 13,
            lineHeight: 1.45,
            outline: 'none',
            boxSizing: 'border-box',
            overflow: 'auto',
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word',
            tabSize: 2,
            WebkitTextFillColor: 'transparent',
            scrollbarWidth: 'none', // Firefox
            msOverflowStyle: 'none'  // IE/Edge
        },
        leftTip: {
            marginTop: 8,
            color: '#bcd3e6',
            fontSize: '0.9em',
            flexShrink: 0
        },
        rightColumn: {
            flex: 1,
            minWidth: 0,
            display: 'flex',
            flexDirection: 'column',
            minHeight: 0
        },
        responseCard: {
            flex: 1,
            display: 'flex',
            minHeight: 0,
            borderRadius: 8,
            border: '1px solid #e6eef620',
            background: '#f6fbff',
            overflow: 'hidden'
        },
        responseGutter: {
            width: 44,
            padding: '8px 6px',
            boxSizing: 'border-box',
            textAlign: 'right',
            userSelect: 'none',
            color: '#94a3b8',
            fontSize: 12,
            lineHeight: 1.45,
            overflow: 'auto'
        },
        responseContentWrap: {
            flex: 1,
            overflow: 'auto',
            whiteSpace: 'pre',
            fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
            fontSize: 13,
            lineHeight: 1.45,
            padding: 12,
            boxSizing: 'border-box'
        },
        jsonStyleTag: `
  .editor-pre, .response-pre {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
    font-size: 13px;
    line-height: 1.45;
    tab-size: 2;
    -moz-tab-size: 2;
    white-space: pre-wrap;
    word-break: break-word;
    overflow-wrap: normal;
    hyphens: none;
  }

  .editor-pre .json-key { color: ${colors.keyColor}; font-weight: 400; }
  .editor-pre .json-string { color: ${colors.stringColor}; font-weight: 400; }
  .editor-pre .json-number { color: #60a5fa; font-weight: 400; }
  .editor-pre .json-boolean { color: #f472b6; font-weight: 400; }
  .editor-pre .json-null { color: #9aa4ad; font-style: italic; font-weight: 400; }

  .response-pre .json-key { color: #0f172a; font-weight: 700; }
  .response-pre .json-string { color: #16a34a; }
  .response-pre .json-number { color: #3b82f6; }
  .response-pre .json-boolean { color: #d946ef; }
  .response-pre .json-null { color: #6b7280; font-style: italic; }

  .editor-pre span, .response-pre span { 
    display: inline; 
    font: inherit;
    letter-spacing: inherit;
  }

  /* Hide scrollbar for webkit browsers (Chrome, Safari) */
  textarea::-webkit-scrollbar {
    display: none;
  }
`
    }

    const JsonStyles = () => <style dangerouslySetInnerHTML={{ __html: styles.jsonStyleTag }} />

    const renderLineNumbers = (count) => {
        const arr = new Array(count).fill(0)
        return arr.map((_, i) => (
            <div key={i} style={{ height: '1.45em', lineHeight: '1.45em', paddingRight: 6 }}>{i + 1}</div>
        ))
    }

    return (
        <div style={styles.root}>
            <JsonStyles />
            
            {/* Tabs */}
            <div style={styles.tabsRow}>
                {tabs.map(t => {
                    const active = t.id === activeId
                    return (
                        <div key={t.id} style={styles.tab(active)} onClick={() => switchTab(t.id)}>
                            {renamingId === t.id ? (
                                <input
                                    ref={renameInputRef}
                                    defaultValue={t.title}
                                    onBlur={(e) => finishRename(t.id, e.target.value)}
                                    onKeyDown={(e) => { if (e.key === 'Enter') finishRename(t.id, e.target.value) }}
                                    style={{ fontSize: 13, fontWeight: 700, padding: '4px 6px' }}
                                />
                            ) : (
                                <div style={{ display: 'inline-flex', gap: 8, alignItems: 'center' }}>
                                    <div onDoubleClick={(e) => { e.stopPropagation(); startRename(t.id) }}>{t.title}</div>
                                    <div style={{ fontSize: 12, opacity: 0.65 }}>{t.mode === 'query' ? 'Q' : 'M'}</div>
                                    <button
                                        onClick={(e) => { e.stopPropagation(); closeTab(t.id) }}
                                        aria-label="Close tab"
                                        style={{
                                            background: 'transparent', border: 'none', color: active ? '#071827' : '#cfe8f3', cursor: 'pointer', fontWeight: 700
                                        }}
                                    >×</button>
                                </div>
                            )}
                        </div>
                    )
                })}
                <button title="New tab" onClick={() => addTab({ title: `Query ${tabs.length + 1}`, mode: activeTab?.mode || 'query' })} style={styles.addTabBtn}>+</button>
            </div>

            {/* header */}
            {header}

            <div style={styles.playgroundRow}>
                {/* LEFT: editor */}
                <div style={styles.leftColumn}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, flexShrink: 0 }}>
                        <div style={{ fontWeight: 700, fontSize: 14 }}>{activeTab?.mode === 'query' ? 'Query JSON' : 'Mutation JSON'}</div>
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                            <div style={{
                                display: 'inline-block',
                                padding: '6px 8px',
                                borderRadius: 6,
                                background: 'rgba(255,255,255,0.03)',
                                fontSize: 12,
                                color: '#cfe8f3'
                            }}>{activeTab?.mode === 'query' ? 'read' : 'write'}</div>
                        </div>
                    </div>

                    <div ref={editorWrapperRef} style={styles.editorWrapper}>
                        <div ref={leftGutterRef} style={styles.gutter}>
                            <div style={{ paddingRight: 6 }}>{renderLineNumbers(leftLines)}</div>
                        </div>

                        <div style={styles.highlightedWrap}>
                            <pre
                                ref={leftHighlightRef}
                                aria-hidden
                                className="editor-pre"
                                style={styles.highlightedPre}
                                dangerouslySetInnerHTML={{ __html: syntaxHighlight(activeTab?.input ?? '') }}
                            />
                            <textarea
                                ref={textareaRef}
                                value={activeTab?.input ?? ''}
                                onChange={(e) => updateActive({ input: e.target.value })}
                                onKeyDown={handleEditorKeyDown}
                                onScroll={handleTextareaScroll}
                                spellCheck={false}
                                style={styles.textarea}
                                aria-label="Query editor"
                            />
                        </div>
                    </div>

                    <div style={styles.leftTip}>
                        Tip: Each tab holds a separate query/mutation. Double-click a tab title to rename. New tabs use current mode. Shortcut: Shift+Enter or Ctrl/Cmd+Enter to run. Tab to indent; Shift+Tab to unindent.
                    </div>
                </div>

                {/* RIGHT: response */}
                <div style={styles.rightColumn}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8, flexShrink: 0 }}>
                        <div style={{ fontWeight: 700, fontSize: 14 }}>Response</div>
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                            <div style={{ fontSize: 12, color: '#334155' }}>{activeTab?.output ? `${(activeTab.output.length / 1024).toFixed(2)} KB` : '—'}</div>
                            <div style={{ width: 12, height: 12, borderRadius: 3, background: colors.accent }} />
                        </div>
                    </div>

                    {activeTab?.error ? (
                        <NoticeBox error title="Error" style={{ flexShrink: 0 }}>
                            <pre style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{activeTab.error}</pre>
                        </NoticeBox>
                    ) : null}

                    <div style={styles.responseCard}>
                        <div ref={rightGutterRef} style={styles.responseGutter}>
                            <div style={{ paddingRight: 6 }}>{renderLineNumbers(rightLines)}</div>
                        </div>

                        <div ref={rightContentRef} style={styles.responseContentWrap}>
                            {activeTab?.output ? (
                                <pre className="response-pre" style={{ margin: 0 }} dangerouslySetInnerHTML={{ __html: syntaxHighlight(activeTab.output) }} />
                            ) : (
                                <pre style={{ margin: 0, color: '#475569' }}>No response yet — run a query or mutation.</pre>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}