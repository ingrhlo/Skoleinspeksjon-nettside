import { useDataQuery } from "@dhis2/app-runtime";
import {
  Button,
  Card,
  CircularLoader,
  NoticeBox,
  DataTable,
  DataTableHead,
  DataTableBody,
  DataTableRow,
  DataTableColumnHeader,
  DataTableCell,
  Tag,
} from "@dhis2/ui";
import { IconChevronLeft16 } from "@dhis2/ui-icons";
import { useNavigate, useParams } from "react-router-dom";
import styles from "./EventDetailPage.module.css";

const EVENT_QUERY = {
  event: {
    resource: "tracker/events",
    id: ({ eventId }) => eventId,
    params: {
      fields:
        "event,occurredAt,orgUnit,orgUnitName,dataValues[dataElement,value]",
    },
  },
  orgUnit: {
    resource: "organisationUnits",
    id: ({ orgUnitId }) => orgUnitId,
    params: {
      fields: "id,displayName,name",
    },
  },
};

// Hardcoded data element labels to avoid API delays
const DATA_ELEMENT_LABELS = {
  HcLtOns1ZQO: "Number of learners in a school",
  paoyTAg0cI9: "Number of teachers in a school",
  INpK1I4glqo: "Books (Total)",
  Se1MYpht225: "Seats (Total)",
  QXcKg7GSr4e: "Toilet for boys",
  OGmIo4kFUYr: "Toilet for girls",
  I13NTyLrHBm: "Toilet for teachers",
  ya5SyA5hej4: "Number of classrooms",
};

const EventDetailPage = () => {
  const { schoolId, eventId } = useParams();
  const navigate = useNavigate();

  const { loading, error, data } = useDataQuery(EVENT_QUERY, {
    variables: { eventId, orgUnitId: schoolId },
  });

  const event = data?.event;
  const school = data?.orgUnit;

  if (loading)
    return (
      <div className={styles.container}>
        <CircularLoader />
      </div>
    );

  if (error)
    return (
      <div className={styles.container}>
        <NoticeBox error title="Error loading event">
          {error.message}
        </NoticeBox>
      </div>
    );

  if (!event)
    return (
      <div className={styles.container}>
        <NoticeBox warning title="Event not found">
          The requested inspection event could not be found.
        </NoticeBox>
      </div>
    );

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <Button
          small
          secondary
          icon={<IconChevronLeft16 />}
          onClick={() => navigate(`/schools/${schoolId}`)}
        >
          Back to School
        </Button>
      </div>

      <Card className={styles.reportCard}>
        <div className={styles.reportHeader}>
          <h1 className={styles.reportTitle}>School Inspection Report</h1>
          <Tag positive>Completed</Tag>
        </div>

        <div className={styles.metadataSection}>
          <div className={styles.metadataGrid}>
            <div className={styles.metadataItem}>
              <span className={styles.metadataLabel}>School:</span>
              <span className={styles.metadataValue}>
                {school?.displayName ||
                  school?.name ||
                  event.orgUnitName ||
                  "Unknown School"}
              </span>
            </div>
            <div className={styles.metadataItem}>
              <span className={styles.metadataLabel}>Inspection Date:</span>
              <span className={styles.metadataValue}>
                {new Date(event.occurredAt).toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </span>
            </div>
            <div className={styles.metadataItem}>
              <span className={styles.metadataLabel}>Event ID:</span>
              <span className={styles.metadataValue}>{event.event}</span>
            </div>
          </div>
        </div>

        <div className={styles.dataSection}>
          <h2 className={styles.sectionTitle}>Inspection Data</h2>
          {event.dataValues && event.dataValues.length > 0 ? (
            <DataTable>
              <DataTableHead>
                <DataTableRow>
                  <DataTableColumnHeader>Data Element</DataTableColumnHeader>
                  <DataTableColumnHeader>Value</DataTableColumnHeader>
                </DataTableRow>
              </DataTableHead>
              <DataTableBody>
                {event.dataValues.map((dv, i) => {
                  const displayName = DATA_ELEMENT_LABELS[dv.dataElement];
                  return (
                    <DataTableRow key={i}>
                      <DataTableCell>
                        <strong>{displayName || dv.dataElement}</strong>
                        {displayName && (
                          <div className={styles.dataElementId}>
                            ID: {dv.dataElement}
                          </div>
                        )}
                      </DataTableCell>
                      <DataTableCell>{dv.value}</DataTableCell>
                    </DataTableRow>
                  );
                })}
              </DataTableBody>
            </DataTable>
          ) : (
            <NoticeBox title="No data">
              No inspection data recorded for this event.
            </NoticeBox>
          )}
        </div>
      </Card>
    </div>
  );
};

export default EventDetailPage;
