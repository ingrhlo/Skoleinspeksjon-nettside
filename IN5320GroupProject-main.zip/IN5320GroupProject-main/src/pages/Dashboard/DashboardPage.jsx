import {
  useDataQuery,
  useDataMutation,
  useDataEngine,
} from "@dhis2/app-runtime";
import {
  Card,
  Button,
  DataTable,
  DataTableHead,
  DataTableBody,
  DataTableRow,
  DataTableCell,
  DataTableColumnHeader,
  CircularLoader,
  NoticeBox,
  ButtonStrip,
  CenteredContent,
  Input,
  Tag,
  IconView16,
  IconDelete16,
  IconAdd16,
} from "@dhis2/ui";
import { useMemo, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./DashboardPage.module.css";

// OrgUnit ID for the cluster - change this if you use a different cluster
const CLUSTER_ORG_UNIT_ID = "Jj1IUjjPaWf"; // Jambalaya Cluster

const SCHOOL_INSPECTION_PROGRAM_ID = "UxK2o06ScIe";
// Threshold for when a school needs follow-up (days since last recorded inspection)
const FOLLOW_UP_THRESHOLD_DAYS = 90;

const query = {
  orgUnits: {
    resource: `organisationUnits/${CLUSTER_ORG_UNIT_ID}`,
    params: {
      paging: false,
      fields: [
        "id",
        "displayName",
        "name",
        "children[id,displayName,name,level,parent[id,displayName],geometry]",
      ],
    },
  },
};

const deleteMutation = {
  resource: "organisationUnits",
  type: "delete",
  id: ({ id }) => id,
};

const DashboardPage = () => {
  const navigate = useNavigate();
  const engine = useDataEngine();
  const { loading, error, data, refetch } = useDataQuery(query);
  const [mutate, { loading: deleting }] = useDataMutation(deleteMutation);
  const [deletingId, setDeletingId] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all"); // all, needs-follow-up, up-to-date
  const [allEvents, setAllEvents] = useState([]);

  useEffect(() => {
    const fetchAllEvents = async () => {
      if (!data?.orgUnits?.children) return;

      const schools = data.orgUnits.children.filter((ou) => ou.level === 5);
      const results = await Promise.all(
        schools.map((school) =>
          engine
            .query(
              {
                events: {
                  resource: "tracker/events",
                  params: ({ orgUnitId }) => ({
                    program: SCHOOL_INSPECTION_PROGRAM_ID,
                    orgUnit: orgUnitId,
                    fields: "event,occurredAt",
                    order: "occurredAt:desc",
                    pageSize: 1,
                  }),
                },
              },
              { variables: { orgUnitId: school.id } }
            )
            .then((result) => {
              const events =
                result.events?.events ?? result.events?.instances ?? [];
              return {
                schoolId: school.id,
                events: Array.isArray(events) ? events : [],
              };
            })
            .catch((err) => {
              console.error(
                `Failed to fetch events for ${school.displayName}:`,
                err
              );
              return { schoolId: school.id, events: [] };
            })
        )
      );

      const eventsMap = {};
      results.forEach(({ schoolId, events }) => {
        eventsMap[schoolId] = events;
      });
      setAllEvents(eventsMap);
    };

    fetchAllEvents();
  }, [data, engine]);

  const schools = useMemo(() => {
    if (!data?.orgUnits?.children) return [];
    // Level 5 = schools in this dataset
    const schoolOUs = data.orgUnits.children.filter((ou) => ou.level === 5);

    return schoolOUs.map((ou) => {
      const latestEvent = allEvents[ou.id]?.[0];
      const daysSinceLastEvent = latestEvent
        ? Math.floor(
            (Date.now() - new Date(latestEvent.occurredAt).getTime()) /
              (1000 * 60 * 60 * 24)
          )
        : null;

      const needsFollowUp =
        !latestEvent || daysSinceLastEvent > FOLLOW_UP_THRESHOLD_DAYS;

      return {
        id: ou.id,
        displayName: ou.displayName ?? ou.name,
        parentName: ou.parent?.displayName ?? "—",
        lastInspectionDate: latestEvent?.occurredAt || null,
        daysSinceLastEvent,
        status: needsFollowUp ? "needs-follow-up" : "up-to-date",
      };
    });
  }, [data, allEvents]);

  const handleSchoolClick = (schoolId) => {
    navigate(`/schools/${schoolId}`);
  };

  const handleAddSchool = () => {
    navigate("/schools/new");
  };

  const handleDeleteSchool = async (schoolId, schoolName) => {
    if (
      !window.confirm(
        `Are you sure you want to delete "${schoolName}"? This action cannot be undone.`
      )
    ) {
      return;
    }

    setDeletingId(schoolId);
    try {
      await mutate({ id: schoolId });
      alert(`School "${schoolName}" has been deleted successfully.`);
      // Refetch the data to update the list
      refetch();
    } catch (err) {
      const message =
        err.details?.httpStatusCode === 409
          ? `Cannot delete "${schoolName}" because it has inspection reports. Delete the reports first from the school detail page.`
          : `Failed to delete school: ${err.message}`;
      alert(message);
    } finally {
      setDeletingId(null);
    }
  };

  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return "—";
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  // Filter and search schools
  const filteredSchools = useMemo(() => {
    return schools.filter((school) => {
      // Search filter
      const matchesSearch = school.displayName
        .toLowerCase()
        .includes(searchTerm.toLowerCase());

      // Status filter
      const matchesStatus =
        statusFilter === "all" || school.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [schools, searchTerm, statusFilter]);

  return (
    <div className={styles.container}>
      <Card className={styles.mainCard}>
        {loading && (
          <CenteredContent>
            <CircularLoader />
            <p>Loading schools and inspection data…</p>
          </CenteredContent>
        )}

        {error && (
          <NoticeBox error title="Error loading data">
            {error.message}
          </NoticeBox>
        )}

        {!loading && !error && (
          <>
            <div className={styles.pageHeader}>
              <div className={styles.headerContent}>
                <h1 className={styles.pageTitle}>Inspection Overview</h1>
                <p className={styles.pageSubtitle}>
                  Monitor and manage school inspections across the{" "}
                  {data?.orgUnits?.displayName || "cluster"}
                </p>
              </div>
              <Button primary icon={<IconAdd16 />} onClick={handleAddSchool}>
                Register a new school
              </Button>
            </div>
            <div className={styles.filterContainer}>
              <div className={styles.searchBar}>
                <Input
                  placeholder="Search schools by name..."
                  value={searchTerm}
                  onChange={({ value }) => setSearchTerm(value)}
                />
              </div>
              <div className={styles.statusFilter}>
                <ButtonStrip>
                  <Button
                    onClick={() => setStatusFilter("all")}
                    primary={statusFilter === "all"}
                  >
                    All ({schools.length})
                  </Button>
                  <Button
                    onClick={() => setStatusFilter("needs-follow-up")}
                    primary={statusFilter === "needs-follow-up"}
                  >
                    Needs Follow-up (
                    {
                      schools.filter((s) => s.status === "needs-follow-up")
                        .length
                    }
                    )
                  </Button>
                  <Button
                    onClick={() => setStatusFilter("up-to-date")}
                    primary={statusFilter === "up-to-date"}
                  >
                    Up to Date (
                    {schools.filter((s) => s.status === "up-to-date").length})
                  </Button>
                </ButtonStrip>
              </div>
            </div>

            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Schools Overview</h2>
              <span className={styles.resultCount}>
                {filteredSchools.length}
                {searchTerm || statusFilter !== "all"
                  ? ` of ${schools.length}`
                  : ""}{" "}
                {filteredSchools.length === 1 ? "school" : "schools"}
              </span>
            </div>

            {filteredSchools.length === 0 ? (
              <NoticeBox warning title="No schools found">
                {searchTerm
                  ? `No schools match your search "${searchTerm}".`
                  : "There are no schools to display. Click 'Add New School' to create one."}
              </NoticeBox>
            ) : (
              <>
                <div className={styles.desktopTable}>
                  <DataTable>
                    <DataTableHead>
                      <DataTableRow>
                        <DataTableColumnHeader>
                          School Name
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>
                          Last Inspection
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>
                          Days Since
                        </DataTableColumnHeader>
                        <DataTableColumnHeader>Status</DataTableColumnHeader>
                        <DataTableColumnHeader>Actions</DataTableColumnHeader>
                      </DataTableRow>
                    </DataTableHead>
                    <DataTableBody>
                      {filteredSchools.map((school) => (
                        <DataTableRow
                          key={school.id}
                          className={styles.clickableRow}
                          onClick={() => handleSchoolClick(school.id)}
                        >
                          <DataTableCell>
                            <strong>{school.displayName}</strong>
                          </DataTableCell>
                          <DataTableCell>
                            {formatDate(school.lastInspectionDate)}
                          </DataTableCell>
                          <DataTableCell>
                            {school.daysSinceLastEvent != null
                              ? school.daysSinceLastEvent
                              : "—"}
                          </DataTableCell>
                          <DataTableCell>
                            {school.status === "needs-follow-up" ? (
                              <Tag negative>Needs Follow-up</Tag>
                            ) : (
                              <Tag positive>Up to Date</Tag>
                            )}
                          </DataTableCell>
                          <DataTableCell onClick={(e) => e.stopPropagation()}>
                            <ButtonStrip>
                              <Button
                                small
                                icon={<IconView16 />}
                                onClick={() => handleSchoolClick(school.id)}
                              >
                                <span className={styles.buttonText}>
                                  View Details
                                </span>
                              </Button>
                              <Button
                                small
                                destructive
                                icon={<IconDelete16 />}
                                onClick={() =>
                                  handleDeleteSchool(
                                    school.id,
                                    school.displayName
                                  )
                                }
                                disabled={deletingId === school.id}
                                loading={deletingId === school.id}
                              >
                                <span className={styles.buttonText}>
                                  {deletingId === school.id
                                    ? "Deleting..."
                                    : "Delete"}
                                </span>
                              </Button>
                            </ButtonStrip>
                          </DataTableCell>
                        </DataTableRow>
                      ))}
                    </DataTableBody>
                  </DataTable>
                </div>

                <div className={styles.mobileCards}>
                  {filteredSchools.map((school) => (
                    <Card key={school.id} className={styles.mobileCard}>
                      <div
                        className={styles.cardHeader}
                        onClick={() => handleSchoolClick(school.id)}
                      >
                        <h3>{school.displayName}</h3>
                        {school.status === "needs-follow-up" ? (
                          <Tag negative>Needs Follow-up</Tag>
                        ) : (
                          <Tag positive>Up to Date</Tag>
                        )}
                      </div>
                      <div
                        className={styles.cardContent}
                        onClick={() => handleSchoolClick(school.id)}
                      >
                        <div className={styles.cardRow}>
                          <span>Last inspection:</span>
                          <strong>
                            {formatDate(school.lastInspectionDate)}
                          </strong>
                        </div>
                        <div className={styles.cardRow}>
                          <span>Days since:</span>
                          <strong>
                            {school.daysSinceLastEvent != null
                              ? school.daysSinceLastEvent
                              : "—"}
                          </strong>
                        </div>
                      </div>
                      <div className={styles.cardActions}>
                        <Button
                          small
                          icon={<IconView16 />}
                          onClick={() => handleSchoolClick(school.id)}
                        >
                          View Details
                        </Button>
                        <Button
                          small
                          destructive
                          icon={<IconDelete16 />}
                          onClick={() =>
                            handleDeleteSchool(school.id, school.displayName)
                          }
                          disabled={deletingId === school.id}
                          loading={deletingId === school.id}
                        >
                          {deletingId === school.id ? "Deleting..." : "Delete"}
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </>
            )}
          </>
        )}
      </Card>
    </div>
  );
};
export default DashboardPage;
