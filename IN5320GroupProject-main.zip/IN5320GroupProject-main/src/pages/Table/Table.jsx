import { useDataQuery } from '@dhis2/app-runtime';
import {
    Table,
    TableBody,
    TableCell,
    TableCellHead,
    TableHead,
    TableRow,
    TableRowHead,
} from '@dhis2/ui';

// define constants
const instance = "https://research.im.dhis2.org/in5320g02/";
const schoolInspectionProgramId = "UxK2o06ScIe";
const jambalayaClusterOrgUnitId = "Jj1IUjjPaWf";

const request = {
    orgUnits: {
        resource: `organisationUnits/${jambalayaClusterOrgUnitId}/children`,
        params: {
            paging: false,
            fields: ['id', 'displayName', 'level', 'parent[displayName]'],
        },
    },
}

function MyTable() {
    const { loading, error, data } = useDataQuery(request)

    if (loading) {
        return <span>Loading...</span>
    }

    if (error) {
        return <span>Error: {error.message}</span>
    }

    console.log('Here is response data: ')
    console.log(data.orgUnits.organisationUnits)

    return (
        <div >
            <Table>
                <TableHead>
                    <TableRowHead>
                        <TableCellHead>orgUnit</TableCellHead>
                        <TableCellHead>Name</TableCellHead>
                        <TableCellHead>Level</TableCellHead>
                        <TableCellHead>Parent</TableCellHead>
                    </TableRowHead>
                </TableHead>
                <TableBody>
                    {(data.orgUnits.organisationUnits || []).map((orgUnit) => (
                        // show only level 5 orgunits
                            orgUnit.level === 5 && (
                                <TableRow key={orgUnit.id}>
                                    <TableCell>{orgUnit.id}</TableCell>
                                    <TableCell>{orgUnit.displayName}</TableCell>
                                    <TableCell>{orgUnit.level}</TableCell>
                                    <TableCell>
                                        {orgUnit.parent?.displayName}
                                    </TableCell>
                                </TableRow>
                            )
                    ))}
                </TableBody>
            </Table>
        </div>
    )
}

export default MyTable;

function fetchAllPrograms(){
    const programsRequest = {
        programs: {
            resource: 'programs',
            params: {
                paging: false,
                fields: ['id', 'displayName'],
            },
        },
    }
    
    const { loading, error, data } = useDataQuery(programsRequest)

    return {loading, error, data}
}

function getProgramId(AllPrograms, programName){
    // find program with name "School Inspections Program"
    const program = AllPrograms.programs.find((program) => program.displayName === programName);
    return program ? program.id : null;
}

function fetchEventsForProgram(programId){
    const eventsRequest = {
        events: {
            resource: 'tracker/events',
            params: {
                paging: false,
                program: programId,
                fields: [
                    'event',
                    'status',
                    'occurredAt',
                    'orgUnit',
                    'createdBy[username]',
                ],
            },
        },
    }
    
    const { loading, error, data } = useDataQuery(eventsRequest)

    return { loading, error, data }
}

function fetchEventsForSchoolInspectionProgram(){
    const { loading: loadingPrograms, error: errorPrograms, data: dataPrograms } = fetchAllPrograms();

    if (loadingPrograms || errorPrograms) {
        return { loading: loadingPrograms, error: errorPrograms, data: null };
    }

    const programId = getProgramId(dataPrograms, "School Inspections Program");

    if (!programId) {
        return { loading: false, error: new Error("Program not found"), data: null };
    }

    return fetchEventsForProgram(programId);
}

function fetchChildrenOfJambalayaCluster(){
    const childrenRequest = {
        children: {
            resource: `organisationUnits/${jambalayaClusterOrgUnitId}/children`,
            params: {
                paging: false
            },
        },
    }
    
    const { loading, error, data } = useDataQuery(childrenRequest)

    return { loading, error, data }
} 

function fetchSchoolInspectionsInJambalayaCluster(){
    const { loading, error, data } = fetchEventsForSchoolInspectionProgram();
    if (loading || error) {
        return { loading, error, data: null };
    }

    //filter events to include only those in orgunits that are children of Jambalaya Cluster
    const { loading: loadingChildren, error: errorChildren, data: dataChildren } = fetchChildrenOfJambalayaCluster();
    if (loadingChildren || errorChildren) {
        return { loading: loadingChildren, error: errorChildren, data: null };
    }

    // create a set of orgunit ids that are children of Jambalaya Cluster
    const jambalayaChildOrgUnitIds = new Set(dataChildren.children.organisationUnits.map((ou) => ou.id));

    // filter events to include only those whose orgUnit is in the set
    const filteredEvents = data.events.trackerEvents.filter((event) =>
        jambalayaChildOrgUnitIds.has(event.orgUnit)
    );

    return { loading: false, error: null, data: filteredEvents };
}