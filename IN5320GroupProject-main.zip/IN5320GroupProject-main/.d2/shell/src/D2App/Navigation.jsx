// src/components/Navigation.jsx
import { Menu, MenuItem } from "@dhis2/ui";
import { useLocation, useNavigate } from "react-router-dom";

function Navigation() {
    const navigate = useNavigate();
    const location = useLocation();

    return (
        <nav>
            <Menu>
                <MenuItem 
                    label="Dashboard"
                    active={location.pathname === "/"}
                    onClick={() => navigate("/")}
                />
                {/* <MenuItem 
                    label="Table"
                    active={location.pathname === "/table"}
                    onClick={() => navigate("/table")}
                />
                <MenuItem 
                    label="Playground"
                    active={location.pathname === "/playground"}
                    onClick={() => navigate("/playground")}
                /> */}
            </Menu>
        </nav>
    );
}

export default Navigation;
