// src/App.jsx
import { BrowserRouter, Route, Routes } from "react-router-dom";

import "./App.module.css";
import CreateInspectionPage from "./pages/CreateInspection/CreateInspectionPage";
import CreateSchoolPage from "./pages/CreateSchool/CreateSchoolPage";
import DashboardPage from "./pages/Dashboard/DashboardPage";
import EventDetailPage from "./pages/EventDetailPage/EventDetailPage";
import SchoolDetailPage from "./pages/SchoolDetail/SchoolDetailPage";

import Playground from "./pages/Playground/PlaygroundPage";
import MyTable from "./pages/Table/Table";


const App = () => {
  return (
    // Bruk ditt eksisterende Provider-oppsett som du allerede har (ikke endre auth)
    <BrowserRouter>
      <div className="app">
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/schools/new" element={<CreateSchoolPage />} />
          <Route path="/schools/:id" element={<SchoolDetailPage />} />

          


          <Route path="/schools/:id/CreateInspection" element={<CreateInspectionPage />} />
          {/* Ny rute for tabellen */}
          <Route path="/table" element={<MyTable />} />
          <Route path="/Playground" element={<Playground />} />
          <Route path="/schools/:schoolId/events/:eventId" element={<EventDetailPage />} />

        </Routes>
      </div>
    </BrowserRouter>
  );
};

export default App;