# School Inspection App

This is a DHIS2 web application designed to help manage and track school inspections within the Jambalaya Cluster.

## Functionality

The application offers the following key features:

*   **Dashboard Overview**: Provides a comprehensive list of all schools in the cluster.
*   **Status Tracking**: Automatically calculates and displays the inspection status for each school. Schools are flagged as "Needs Follow-up" if they haven't had an inspection recorded in the last 90 days.
*   **Search & Filter**: Users can search for specific schools by name or filter the list based on their inspection status (e.g., "Needs Follow-up" vs. "Up to date").
*   **School Management**:
    *   **Create School**: Functionality to register new schools (Organisation Units) into the system.
    *   **Delete School**: Option to remove schools from the system.
*   **Inspection Management**:
    *   **Record Inspections**: Forms to create and submit new inspection reports (Events) for a specific school.
    *   **Inspection History**: View a detailed history of past inspections for any given school.
    *   **Event Details**: Drill down into specific inspection events to view recorded data.
*   **Minimum Standards for Ratios**: Calculates and displays key resource ratios (e.g., Seat-to-learner, Learner-to-teacher) based on inspection data and indicates whether they meet the required standards.

## Implementation

This project is built using the **DHIS2 App Platform** and standard web technologies:

*   **Framework**: The application is built with **React**.
*   **DHIS2 Integration**:
    *   It uses **`@dhis2/app-runtime`** for all interactions with the DHIS2 Web API.
    *   **Data Fetching**: Custom hooks like `useDataQuery` and `useDataMutation` are used to fetch Organisation Units (schools) and Tracker Events (inspections).
    *   **Data Model**:
        *   **Schools** are represented as DHIS2 Organisation Units (specifically filtered for Level 5 units).
        *   **Inspections** are stored as Tracker Events associated with the "School Inspection" Program.
*   **UI Components**: The user interface is constructed using **`@dhis2/ui`**, ensuring consistency with the DHIS2 design system.
*   **Routing**: **`react-router-dom`** handles client-side navigation between the dashboard, school details, and creation forms.

## Known Limitations

*   **Organisation Unit Display**: Initially when viewing inspection reports, organisation units are displayed as IDs rather than their names.
*   **Status Tracking**: Status tracking could be enhanced using DHIS2's resource count functionality.
*   **Notes**: The ability to add notes to inspection reports is not currently implemented.


## Table of contents
- [Prerequisites](#prerequisites)
- [Quick start](#quick-start)
- [Scripts](#scripts)
- [Useful links](#useful-links)
- [Troubleshooting](#troubleshooting)

## Prerequisites
- Node.js (LTS)
- Yarn or npm
- Access to a running DHIS2 backend for local development

## Quick start

1. Start the DHIS2 backend (example):
    ```
    npx dhis-portal --target=https://research.im.dhis2.org/in5320g02
    ```

2. Install dependencies:
    ```
    yarn install
    ```

3. Start the development server:
    ```
    yarn start
    ```
    Open http://localhost:3000 — the app reloads on edits and lint errors appear in the console.

Credentials for the example backend:
```
Username: in5320
Password: P1@tform
```

## Scripts

- `yarn start` — Run the app in development mode.
- `yarn test` — Run tests located in `/src`. See: https://platform.dhis2.nu/#/scripts/test
- `yarn build` — Build a production bundle in the `build` folder. A deployable `.zip` is available at `build/bundle`. See: https://platform.dhis2.nu/#/scripts/build
- `yarn deploy` — Deploy the built app to a DHIS2 instance (prompts for server URL and credentials). Run `yarn build` before `yarn deploy`. See: https://platform.dhis2.nu/#/scripts/deploy

## Useful links
- DHIS2 Application Platform docs: https://platform.dhis2.nu/
- DHIS2 Application Runtime docs: https://runtime.dhis2.nu/
- React docs: https://reactjs.org/

## Troubleshooting

- If the app doesn't load, confirm the DHIS2 backend URL is reachable and credentials are correct.
- If dependency installation fails, try removing `node_modules` and reinstalling (`yarn install`).